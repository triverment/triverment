/* @(#)version.h	1.93 16/12/15 Copyright 2007-2016 J. Schilling */

/*
 * The version for cdrtools programs
 */
#define	VERSION	"3.02a07"
